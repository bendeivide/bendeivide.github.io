---
# Generate Wowchemy CMS
type: wowchemycms
private: true
outputs:
- wowchemycms_config
- HTML
---
